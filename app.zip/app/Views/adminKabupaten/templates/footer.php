  <!-- app/views/adminKabupaten/templates/footer.php -->
  <!-- Footer -->
  <footer class="bg-success text-white py-3 mt-auto text-center">
    <p class="small mb-0">&copy; 2025 Pemerintah Kabupaten Pringsewu. All rights reserved.</p>
  </footer>

  <!-- jQuery (required for Select2) -->
  <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
  <!-- Bootstrap JS -->
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
  <!-- Select2 JS -->
  <script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>